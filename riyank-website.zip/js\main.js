// ========================================
// Riyank - Government Services Website JS
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initNavbar();
    initFAQ();
    initSmoothScroll();
    initAnimations();
    loadDynamicContent();
    initContactForm();
});

// ========================================
// NAVBAR
// ========================================
function initNavbar() {
    const navbar = document.querySelector('.navbar');
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    // Scroll effect
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // Mobile menu toggle
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            navToggle.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
                navMenu.classList.remove('active');
                navToggle.classList.remove('active');
            }
        });
    }
}

// ========================================
// FAQ ACCORDION
// ========================================
function initFAQ() {
    var faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(function(item) {
        var question = item.querySelector('.faq-question');
        
        if (question) {
            question.addEventListener('click', function() {
                var isActive = item.classList.contains('active');
                
                // Close all other items
                faqItems.forEach(function(otherItem) {
                    otherItem.classList.remove('active');
                });
                
                // Toggle current item
                if (!isActive) {
                    item.classList.add('active');
                }
            });
        }
    });
}

// ========================================
// SMOOTH SCROLL
// ========================================
function initSmoothScroll() {
    var links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(function(link) {
        link.addEventListener('click', function(e) {
            var href = link.getAttribute('href');
            
            if (href !== '#') {
                e.preventDefault();
                
                var target = document.querySelector(href);
                
                if (target) {
                    var offsetTop = target.offsetTop - 80;
                    
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

// ========================================
// ANIMATIONS
// ========================================
function initAnimations() {
    // Intersection Observer for scroll animations
    var observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    var observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe elements
    document.querySelectorAll('.feature-card, .step-card, .service-card').forEach(function(el) {
        el.classList.add('animate-on-scroll');
        observer.observe(el);
    });
}

// ========================================
// DYNAMIC CONTENT LOADER
// ========================================
function loadDynamicContent() {
    // Load testimonials
    loadTestimonials();
}

// Load testimonials for Riyank
function loadTestimonials() {
    var slider = document.querySelector('.testimonials-slider');
    if (!slider) return;

    var testimonials = getRiyankTestimonials();
    var currentIndex = 0;

    // Create testimonial HTML
    var renderTestimonial = function(index) {
        var t = testimonials[index];
        var starsHtml = '';
        for (var i = 0; i < 5; i++) {
            starsHtml += '<i class="fas fa-star"></i>';
        }
        
        slider.innerHTML = '<div class="testimonial-card">' +
            '<div class="testimonial-rating">' + starsHtml + '</div>' +
            '<p class="testimonial-text">"' + t.text + '"</p>' +
            '<div class="testimonial-author">' +
                '<div class="testimonial-avatar">' + t.initials + '</div>' +
                '<div class="testimonial-info">' +
                    '<h5>' + t.name + '</h5>' +
                    '<p>' + t.location + '</p>' +
                '</div>' +
            '</div>' +
        '</div>';
    };

    // Auto-rotate testimonials
    setInterval(function() {
        currentIndex = (currentIndex + 1) % testimonials.length;
        renderTestimonial(currentIndex);
    }, 5000);

    renderTestimonial(0);
}

// Riyank Testimonials Data
function getRiyankTestimonials() {
    return [
        {
            name: 'Rahul Sharma',
            location: 'Delhi',
            text: 'Riyank made my passport application so easy! They handled everything and I just had to provide documents. Highly recommended!',
            initials: 'RS'
        },
        {
            name: 'Priya Patel',
            location: 'Mumbai',
            text: 'Got my driving license renewed within 3 days. Excellent service and professional staff. Will definitely use again.',
            initials: 'PP'
        },
        {
            name: 'Amit Kumar',
            location: 'Bangalore',
            text: 'Applied for my son\'s birth certificate through Riyank. The entire process was smooth and hassle-free. Great experience!',
            initials: 'AK'
        },
        {
            name: 'Sneha Reddy',
            location: 'Hyderabad',
            text: 'Very efficient service for visa application. They guided me through every step and the process was much easier than doing it alone.',
            initials: 'SR'
        },
        {
            name: 'Vikram Singh',
            location: 'Chennai',
            text: 'Excellent help with Aadhaar card update. The team was very supportive and the service was completed quickly. Thank you Riyank!',
            initials: 'VS'
        }
    ];
}

// ========================================
// CONTACT FORM HANDLING
// ========================================
function initContactForm() {
    var form = document.getElementById('contact-form');
    
    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        var formData = new FormData(form);
        var data = {};
        formData.forEach(function(value, key) {
            data[key] = value;
        });
        
        // Add timestamp
        data.date = new Date().toISOString();
        data.id = Date.now();
        
        // Save customer details
        saveCustomerData(data);
        
        // Show success message
        showSuccessMessage();
        
        // Reset form
        form.reset();
    });
}

function saveCustomerData(data) {
    // Get existing customers
    var customers = JSON.parse(localStorage.getItem('riyank_customers') || '[]');
    
    // Add new customer
    customers.push(data);
    
    // Save to localStorage
    localStorage.setItem('riyank_customers', JSON.stringify(customers));
    
    // Also log to console for easy access
    console.log('New Customer Submitted:', data);
    console.log('Total Customers:', customers.length);
}

function showSuccessMessage() {
    // Create success message element
    var messageDiv = document.createElement('div');
    messageDiv.className = 'success-message';
    messageDiv.innerHTML = '<i class="fas fa-check-circle"></i> Thank you! Your request has been submitted. We will contact you soon!';
    
    // Add styles
    messageDiv.style.cssText = 'position: fixed; top: 100px; left: 50%; transform: translateX(-50%); background: #10B981; color: white; padding: 20px 40px; border-radius: 10px; font-size: 1rem; font-weight: 500; z-index: 9999; box-shadow: 0 10px 25px rgba(0,0,0,0.2); animation: slideDown 0.3s ease;';
    
    // Add animation keyframes if not exists
    if (!document.getElementById('success-animation')) {
        var style = document.createElement('style');
        style.id = 'success-animation';
        style.innerHTML = '@keyframes slideDown { from { transform: translateX(-50%) translateY(-20px); opacity: 0; } to { transform: translateX(-50%) translateY(0); opacity: 1; } }';
        document.head.appendChild(style);
    }
    
    document.body.appendChild(messageDiv);
    
    // Remove after 4 seconds
    setTimeout(function() {
        messageDiv.style.animation = 'slideUp 0.3s ease forwards';
        setTimeout(function() {
            messageDiv.remove();
        }, 300);
    }, 4000);
}

// ========================================
// UTILITY FUNCTIONS
// ========================================
function showNotification(message, type) {
    if (type === undefined) type = 'success';
    
    var notification = document.createElement('div');
    notification.className = 'notification notification-' + type;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(function() {
        notification.classList.add('show');
    }, 100);
    
    setTimeout(function() {
        notification.classList.remove('show');
        setTimeout(function() {
            notification.remove();
        }, 300);
    }, 3000);
}

// Export for admin use
window.Riyank = {
    showNotification: showNotification,
    saveCustomerData: saveCustomerData,
    getCustomers: function() {
        return JSON.parse(localStorage.getItem('riyank_customers') || '[]');
    }
};

