// Excel Export Utility for HR AI
// This script enables exporting user data to Excel format

(function() {
    // Load SheetJS library dynamically
    function loadSheetJS() {
        return new Promise(function(resolve, reject) {
            if (window.XLSX) {
                resolve(window.XLSX);
                return;
            }
            
            var script = document.createElement('script');
            script.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
            script.onload = function() {
                resolve(window.XLSX);
            };
            script.onerror = function() {
                reject(new Error('Failed to load SheetJS library'));
            };
            document.head.appendChild(script);
        });
    }

    // Export leads to Excel
    window.exportLeadsToExcel = async function() {
        try {
            var XLSX = await loadSheetJS();
            
            var leads = JSON.parse(localStorage.getItem('hr_ai_leads') || '[]');
            
            if (leads.length === 0) {
                alert('No data to export!');
                return;
            }

            // Prepare data for Excel
            var data = leads.map(function(lead) {
                return {
                    'ID': lead.id,
                    'Name': lead.name || '',
                    'Email': lead.email || '',
                    'Company': lead.company || '',
                    'Message': lead.message || '',
                    'Date': new Date(lead.date).toLocaleString(),
                    'Status': lead.status || 'new'
                };
            });

            // Create workbook and worksheet
            var wb = XLSX.utils.book_new();
            var ws = XLSX.utils.json_to_sheet(data);

            // Set column widths
            ws['!cols'] = [
                { wch: 10 },  // ID
                { wch: 25 },  // Name
                { wch: 35 },  // Email
                { wch: 25 },  // Company
                { wch: 50 },  // Message
                { wch: 25 },  // Date
                { wch: 15 }   // Status
            ];

            XLSX.utils.book_append_sheet(wb, ws, 'Leads');

            // Generate filename with date
            var date = new Date().toISOString().split('T')[0];
            var filename = 'HR_AI_Leads_' + date + '.xlsx';

            // Download the file
            XLSX.writeFile(wb, filename);
            
            console.log('Excel file exported successfully!');
        } catch (error) {
            console.error('Error exporting to Excel:', error);
            alert('Error exporting data. Please try again.');
        }
    };

    // Export users/signups to Excel
    window.exportUsersToExcel = async function() {
        try {
            var XLSX = await loadSheetJS();
            
            var users = JSON.parse(localStorage.getItem('hr_ai_users') || '[]');
            var signupUser = JSON.parse(localStorage.getItem('hr_ai_user') || 'null');
            
            // Combine all users
            var allUsers = [...users];
            if (signupUser && !users.find(u => u.email === signupUser.email)) {
                allUsers.push(signupUser);
            }

            if (allUsers.length === 0) {
                alert('No user data to export!');
                return;
            }

            // Prepare data for Excel
            var data = allUsers.map(function(user) {
                return {
                    'ID': user.id || Date.now(),
                    'Name': user.name || '',
                    'Email': user.email || '',
                    'Company': user.company || '',
                    'Signup Date': user.date ? new Date(user.date).toLocaleString() : new Date().toLocaleString()
                };
            });

            // Create workbook and worksheet
            var wb = XLSX.utils.book_new();
            var ws = XLSX.utils.json_to_sheet(data);

            // Set column widths
            ws['!cols'] = [
                { wch: 10 },  // ID
                { wch: 30 },  // Name
                { wch: 35 },  // Email
                { wch: 25 },  // Company
                { wch: 25 }   // Date
            ];

            XLSX.utils.book_append_sheet(wb, ws, 'Users');

            // Generate filename with date
            var date = new Date().toISOString().split('T')[0];
            var filename = 'HR_AI_Users_' + date + '.xlsx';

            // Download the file
            XLSX.writeFile(wb, filename);
            
            console.log('Users Excel file exported successfully!');
        } catch (error) {
            console.error('Error exporting users to Excel:', error);
            alert('Error exporting data. Please try again.');
        }
    };

    // Export all data (leads + users) to Excel
    window.exportAllToExcel = async function() {
        try {
            var XLSX = await loadSheetJS();
            
            var leads = JSON.parse(localStorage.getItem('hr_ai_leads') || '[]');
            var users = JSON.parse(localStorage.getItem('hr_ai_users') || '[]');
            var signupUser = JSON.parse(localStorage.getItem('hr_ai_user') || 'null');
            
            var allUsers = [...users];
            if (signupUser && !users.find(u => u.email === signupUser.email)) {
                allUsers.push(signupUser);
            }

            // Create workbook
            var wb = XLSX.utils.book_new();

            // Leads sheet
            if (leads.length > 0) {
                var leadsData = leads.map(function(lead) {
                    return {
                        'ID': lead.id,
                        'Name': lead.name || '',
                        'Email': lead.email || '',
                        'Company': lead.company || '',
                        'Message': lead.message || '',
                        'Date': new Date(lead.date).toLocaleString(),
                        'Status': lead.status || 'new'
                    };
                });
                var leadsWs = XLSX.utils.json_to_sheet(leadsData);
                leadsWs['!cols'] = [
                    { wch: 10 }, { wch: 25 }, { wch: 35 }, { wch: 25 }, { wch: 50 }, { wch: 25 }, { wch: 15 }
                ];
                XLSX.utils.book_append_sheet(wb, leadsWs, 'Leads');
            }

            // Users sheet
            if (allUsers.length > 0) {
                var usersData = allUsers.map(function(user) {
                    return {
                        'ID': user.id || Date.now(),
                        'Name': user.name || '',
                        'Email': user.email || '',
                        'Company': user.company || '',
                        'Date': user.date ? new Date(user.date).toLocaleString() : new Date().toLocaleString()
                    };
                });
                var usersWs = XLSX.utils.json_to_sheet(usersData);
                usersWs['!cols'] = [
                    { wch: 10 }, { wch: 30 }, { wch: 35 }, { wch: 25 }, { wch: 25 }
                ];
                XLSX.utils.book_append_sheet(wb, usersWs, 'Users');
            }

            if (leads.length === 0 && allUsers.length === 0) {
                alert('No data to export!');
                return;
            }

            // Generate filename with date
            var date = new Date().toISOString().split('T')[0];
            var filename = 'HR_AI_Data_' + date + '.xlsx';

            // Download the file
            XLSX.writeFile(wb, filename);
            
            console.log('All data exported to Excel successfully!');
        } catch (error) {
            console.error('Error exporting all data to Excel:', error);
            alert('Error exporting data. Please try again.');
        }
    };

    console.log('Excel Export Utility loaded successfully!');
})();

